package org.example.function

class Validacion {

    fun validarNumeroEntero(minimo: Int, maximo: Int,Texto: String): Int{

        var num= minimo - 1
        while (num < minimo || num > maximo){
            try {
                println("ingrese $Texto entre $minimo y $maximo")
                num = readln().toInt()
                if (num < minimo || num > maximo){
                    println("ERROR: fuera de rango")
                }
            }catch (e: Exception){
                println("ERROR: ingrese texto.....")
            }
        }

        return num

    }
}